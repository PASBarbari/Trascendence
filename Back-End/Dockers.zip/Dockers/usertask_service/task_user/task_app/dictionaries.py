TASK_CATEGORIES = {
	"00": "NONE",
    "SP": "Sport",
    "ED": "Education",
    "HE": "Health",
    "AR": "Art",
    "SS": "Social Skills",
    "MD": "Mindset",
}