from rest_framework import status

error_codes = {
	'an email is needed': 970,
}
